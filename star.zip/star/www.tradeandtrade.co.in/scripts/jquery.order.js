jQuery(document).ready(function(){

	$('#trade-message').hide();
	$('#patent-message').hide();
	$('#design-message').hide();
	$('#copyright-message').hide();

	// Add validation parts
	$('#order-trade input[type=text], #order-trade input[type=email], #order-trade select, #order-trade textarea').each(function(){
		$(this).after('<mark class="validate"></mark>');
	});

	$('#order-patent input[type=text], #order-patent input[type=email], #order-patent select, #order-patent textarea').each(function(){
		$(this).after('<mark class="validate"></mark>');
	});

	$('#order-design input[type=text], #order-design input[type=email], #order-design select, #order-design textarea').each(function(){
		$(this).after('<mark class="validate"></mark>');
	});

	$('#order-copyright input[type=text], #order-copyright input[type=email], #order-copyright select, #order-copyright textarea').each(function(){
		$(this).after('<mark class="validate"></mark>');
	});

	// Validate Trade
	$('#trade-comments').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#trade-email').focusout(function() {
		if (!$(this).val() || !isEmail($(this).val()))
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#trade-name').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#trade-mobilenumber').focusout(function() {
		if (!$(this).val() || !isNumeric($(this).val()))
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#natureofbusiness').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#trade-security').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#trade-submit').click(function(){
		
		$("#trade-message").slideUp(200,function() {
			$('#trade-message').hide();

			// Kick in Validation
			$('#trade-email').triggerHandler("focusout");
			$('#natureofbusiness').triggerHandler("focusout");
			$('#trade-name').triggerHandler("focusout");
			$('#trade-mobilenumber').triggerHandler("focusout");
			$('#trade-comments').triggerHandler("focusout");
			$('#trade-security').triggerHandler("focusout");
			
		});
	});
		

	$('#tradeform').submit(function(){

		$("#trade-message").slideUp(200,function() {
			$('#trade-message').hide();

			// Kick in Validation
			$('#trade-email').triggerHandler("focusout");
			$('#natureofbusiness').triggerHandler("focusout");
			$('#trade-name').triggerHandler("focusout");
			$('#trade-mobilenumber').triggerHandler("focusout");
			$('#trade-comments').triggerHandler("focusout");
			$('#trade-security').triggerHandler("focusout");
			
		});

		if ($('#order-trade mark.error').size()>0) {
			$('#order-trade').effect('shake', { times:2 }, 75);
			return false;
		}

		var action = $(this).attr('action');

 		$('#trade-submit').after('<img src="images/ajax-loader.gif" class="loader" />').attr('disabled','disabled');

		$.post(action, $('#tradeform').serialize(),
			function(data){
				$('.imageBox').fadeOut(500);
       			$("#showimages").html("");
				$("#display_hidden").val("");

				$( '#tradeform' ).each(function(){
				    this.reset();
				});
				$('#tradeform').fadeOut(1000);
				$('#trade-message').html( data );
				$('#trade-message').slideDown();
				$('#tradeform img.loader').fadeOut('slow',function(){$(this).remove()});
				$('#tradeform #trade-submit').removeAttr('disabled');
				if(data.match('success') != null) $('#tradeform #trade-submit').attr("disabled", true);
				$('#tradeform').delay(3000).fadeIn(1000);
			}
		);

		return false;

	});



	// Validate Patent
	$('#patent-comments').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#patent-email').focusout(function() {
		if (!$(this).val() || !isEmail($(this).val()))
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#patent-name').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#patent-mobilenumber').focusout(function() {
		if (!$(this).val() || !isNumeric($(this).val()))
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#patenttitle').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#patent-security').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#patent-submit').click(function(){
		
		$("#patent-message").slideUp(200,function() {
			$('#patent-message').hide();

			// Kick in Validation
			$('#patent-email').triggerHandler("focusout");
			$('#patenttitle').triggerHandler("focusout");
			$('#patent-name').triggerHandler("focusout");
			$('#patent-mobilenumber').triggerHandler("focusout");
			$('#patent-comments').triggerHandler("focusout");
			$('#patent-security').triggerHandler("focusout");
			
		});
	});
		

	$('#patentform').submit(function(){

		$("#patent-message").slideUp(200,function() {
			$('#patent-message').hide();

			// Kick in Validation
			$('#patent-email').triggerHandler("focusout");
			$('#patenttitle').triggerHandler("focusout");
			$('#patent-name').triggerHandler("focusout");
			$('#patent-mobilenumber').triggerHandler("focusout");
			$('#patent-comments').triggerHandler("focusout");
			$('#patent-security').triggerHandler("focusout");
			
		});

		if ($('#order-patent mark.error').size()>0) {
			$('#order-patent').effect('shake', { times:2 }, 75);
			return false;
		}

		var action = $(this).attr('action');

 		$('#patent-submit').after('<img src="images/ajax-loader.gif" class="loader" />').attr('disabled','disabled');

		$.post(action, $('#patentform').serialize(),
			function(data){
				$('.imageBox').fadeOut(500);
       			$("#showimages").html("");
				$("#display_hidden").val("");

				$('#patentform' ).each(function(){
				    this.reset();
				});
				$('#patentform').fadeOut(1000);
				$('#patent-message').html( data );
				$('#patent-message').slideDown();
				$('#patentform img.loader').fadeOut('slow',function(){$(this).remove()});
				$('#patentform #patent-submit').removeAttr('disabled');
				if(data.match('success') != null) $('#patentform #patent-submit').attr("disabled", true);
				$('#patentform').delay(3000).fadeIn(1000);
			}
		);

		return false;

	});


	// Validate Design
	$('#design-comments').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#design-email').focusout(function() {
		if (!$(this).val() || !isEmail($(this).val()))
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#design-name').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#design-mobilenumber').focusout(function() {
		if (!$(this).val() || !isNumeric($(this).val()))
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#designtitle').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#design-security').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});


	$('#design-submit').click(function(){
		
		$("#design-message").slideUp(200,function() {
			$('#design-message').hide();

			// Kick in Validation
			$('#design-email').triggerHandler("focusout");
			$('#designtitle').triggerHandler("focusout");
			$('#design-name').triggerHandler("focusout");
			$('#design-mobilenumber').triggerHandler("focusout");
			$('#design-comments').triggerHandler("focusout");
			$('#design-security').triggerHandler("focusout");
			
		});
	});
		

	$('#designform').submit(function(){

		$("#design-message").slideUp(200,function() {
			$('#design-message').hide();

			// Kick in Validation
			$('#design-email').triggerHandler("focusout");
			$('#patenttitle').triggerHandler("focusout");
			$('#design-name').triggerHandler("focusout");
			$('#design-mobilenumber').triggerHandler("focusout");
			$('#design-comments').triggerHandler("focusout");
			$('#design-security').triggerHandler("focusout");
			
		});

		if ($('#order-design mark.error').size()>0) {
			$('#order-design').effect('shake', { times:2 }, 150);
			return false;
		}

		var action = $(this).attr('action');

 		$('#design-submit').after('<img src="images/ajax-loader.gif" class="loader" />').attr('disabled','disabled');

		$.post(action, $('#designform').serialize(),
			function(data){
				$('.imageBox').fadeOut(500);
       			$("#showimages").html("");
				$("#display_hidden").val("");

				$('#designform' ).each(function(){
				    this.reset();
				});
				$('#designform').fadeOut(1000);
				$('#design-message').html( data );
				$('#design-message').slideDown();
				$('#designform img.loader').fadeOut('slow',function(){$(this).remove()});
				$('#designform #design-submit').removeAttr('disabled');
				if(data.match('success') != null) $('#designform #design-submit').attr("disabled", true);
				$('#designform').delay(3000).fadeIn(1000);
			}
		);

		return false;

	});
	

	// Validate Copyright
	$('#copyright-comments').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#copyright-email').focusout(function() {
		if (!$(this).val() || !isEmail($(this).val()))
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#copyright-name').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#copyright-mobilenumber').focusout(function() {
		if (!$(this).val() || !isNumeric($(this).val()))
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#copyrightwork').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#copyright-security').focusout(function() {
		if (!$(this).val())
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});

	$('#copyright-submit').click(function(){
		
		$("#copyright-message").slideUp(200,function() {
			$('#copyright-message').hide();

			// Kick in Validation
			$('#copyright-email').triggerHandler("focusout");
			$('#copyrightwork').triggerHandler("focusout");
			$('#copyright-name').triggerHandler("focusout");
			$('#copyright-mobilenumber').triggerHandler("focusout");
			$('#copyright-comments').triggerHandler("focusout");
			$('#copyright-security').triggerHandler("focusout");
			
		});
	});
		

	$('#copyrightform').submit(function(){

		$("#copyright-message").slideUp(200,function() {
			$('#copyright-message').hide();

			// Kick in Validation
			$('#copyright-email').triggerHandler("focusout");
			$('#copyrightwork').triggerHandler("focusout");
			$('#copyright-name').triggerHandler("focusout");
			$('#copyright-mobilenumber').triggerHandler("focusout");
			$('#copyright-comments').triggerHandler("focusout");
			$('#copyright-security').triggerHandler("focusout");
			
		});

		if ($('#order-copyright mark.error').size()>0) {
			$('#order-copyright').effect('shake', { times:2 }, 150);
			return false;
		}

		var action = $(this).attr('action');

 		$('#copyright-submit').after('<img src="images/ajax-loader.gif" class="loader" />').attr('disabled','disabled');

		$.post(action, $('#copyrightform').serialize(),
			function(data){
				$('.imageBox').fadeOut(500);
       			$("#showimages").html("");
				$("#display_hidden").val("");

				$('#copyrightform' ).each(function(){
				    this.reset();
				});
				$('#copyrightform').fadeOut(1000);
				$('#copyright-message').html( data );
				$('#copyright-message').slideDown();
				$('#copyrightform img.loader').fadeOut('slow',function(){$(this).remove()});
				$('#copyrightform #copyright-submit').removeAttr('disabled');
				if(data.match('success') != null) $('#copyrightform #copyright-submit').attr("disabled", true);
				$('#copyrightform').delay(3000).fadeIn(1000);
			}
		);

		return false;

	});



	function isEmail(emailAddress) {
		var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
		return pattern.test(emailAddress);
	}

	function isNumeric(input) {
    	return (input - 0) == input && input.length > 0;
	}

});