jQuery(document).ready(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Comment or uncomment the result you want.
	// Currently, shake on error is enabled.
	// When a field is left blank, jQuery will shake the form

	/* Begin config */

	//	var shake = "Yes";
	var shake = "Yes";

	/* End config */

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////// Do not touch below /////////////////////////////////////////

	$('#news-message').hide();

	// Add validation parts
	$('#news-form input[type=email]').each(function(){
		$(this).after('<mark class="validate"></mark>');
	});


	$('#news-email').focusout(function() {
		if (!$(this).val() || !isEmail($(this).val()))
			$(this).addClass('error', 300).parent().find('mark').removeClass('valid').addClass('error');
		else
			$(this).removeClass('error', 300).parent().find('mark').removeClass('error').addClass('valid');
	});


	$('#news-submit').click(function() {
		$("#news-message").slideUp(200,function() {
			$('#news-message').hide();

			// Kick in Validation
			$('#news-email').triggerHandler("focusout");
		});
	});

	$('#news-form').submit(function(){
		if ($('#news-form mark.error').size()>0) {
			if(shake == "Yes") {
				$('#news-form').effect('shake', { times:2 }, 75);
			}
			return false;
		}

		var action = $(this).attr('action');
 		$('#news-submit').after('<img src="images/ajax-loader.gif" class="loader" />').attr('disabled','disabled');
		$.post(action, $('#news-form').serialize(),
			function(data){
				$('#news-form' ).each(function(){
				    this.reset();
				});
				$('#news-form').fadeOut(1000);
				$('#news-message').html( data );
				$('#news-message').slideDown();
				$('#news-form img.loader').fadeOut('slow',function(){$(this).remove()});
				$('#news-form #news-submit').removeAttr('disabled');
				if(data.match('success') != null) $('#news-form #news-submit').attr("disabled", true);
				$('#news-form').delay(1000).fadeIn(1000);
			}
		);
		return false;
	});

	function isEmail(emailAddress) {
		var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
		return pattern.test(emailAddress);
	}

});