﻿//////Ckeck Only Decimal Nos.  Status
function isDecimalNumberKey(txt, evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode == 46) {
        //Check if the text already contains the . character
        if (txt.value.indexOf('.') === -1) {
            return true;
        } else {
            return false;
        }
    } else {
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
    }
    return true;
}
//////Ckeck Only Decimal Nos.  Status

//////Ckeck Only Nos  Status <input type="text"  id="txtTinNo"  onkeypress="return isNumber(event)"  >
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
//////Ckeck Only Nos  Status

function MultiMobileNo(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        if (charCode == 44) {
            return true;
        }
        else {
            return false;
        }
    }
    return true;
}

function IsMobileNo(el, evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    if (el.value.length >= 10)
    {
        return false;
    }
    return true;
}
//////Ckeck Min Length
function CheckMinLength(TextBoxx) {
    debugger;
    var count = 0;
    TextBoxx.forEach(function (textBox) {
        if (textBox.value.length < 10) {
            if (count == 0) {
                alert('Phone No should be 10 digits');
                textBox.focus();
                textBox.style.backgroundColor = "#FBE3E4";
                count = 1;
            }
        }
        else {
            textBox.style.backgroundColor = "#fff";
        }
    });
    if (count == 1)
    { return false; }
    else {
        return true;
    }
}
//////Ckeck Min Length

function CheckEmail(textbox) {

    if (textbox.value != '') {
        var emailPat = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
        var emailid = textbox.value;
        textbox.style.backgroundColor = "#fff";
        var matchArray = emailid.match(emailPat);
        if (matchArray == null) {
            alert("Your email address is incorrect. Please try again.");
            textbox.focus();
            textbox.style.backgroundColor = "#FBE3E4";
            return false;
        }
    } else { return true; }
}
//////Ckeck Valid Email  Status

//////Ckeck Multiple Email Status
function CheckMultiEmail(textbox) {
    debugger;
    var arrValue = txtEmail.value.split(',');
    for (i = 0; i < arrValue.length; i++) {
        var data = arrValue[i];
        if (data != '') {
            var emailPat = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
            var emailid = data.trim();
            textbox.style.backgroundColor = "#fff";
            var matchArray = emailid.match(emailPat);
            if (matchArray == null) {
                alert("Your email address is incorrect. Please try again.");
                textbox.focus();
                textbox.style.backgroundColor = "#FBE3E4";
                return false;
            }
        } else { return true; }
    }

}
//////Ckeck Multiple Email  Status

//////Ckeck Valid Website  Statu

function CheckWebsite(textbox) {

    if (textbox.value != '') {
        var Url = "^[A-Za-z]+://[A-Za-z0-9-_]+\\.[A-Za-z0-9-_%&\?\/.=]+$"
        var tempURL = textbox.value;
        textbox.style.backgroundColor = "#fff";
        var matchURL = tempURL.match(Url);
        if (matchURL == null) {
            alert("Web URL does not look valid");
            textbox.focus();
            textbox.style.backgroundColor = "#FBE3E4";
            return false;
        }
    } else { return true; }
}
//////Ckeck Valid Website  Statu


//////Ckeck Valid PhoneNo  Status
function iSValidPhone(txt) {
    debugger;
    if (txt.value != '') {
        var phoneno = '^(\([0-9]{3}\)|[0-9]{3}-)[0-9]{3}-[0-9]{4}$';
        //var phoneno = /^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;
        txt.style.backgroundColor = "#fff";
        if (!txt.value.match(phoneno)) {
            // alert("Not a valid Phone Number(only receive +, and numbers)");
            //txt.style.backgroundColor = "#FBE3E4";
            //txt.focus();
            return true;
        } else { return true; }
    }
}
//////Ckeck Valid PhoneNo  Status

//////Ckeck TextBox Empty Status
function EmptyCheckTextBox(TextBoxx) {
    var s = true;
    var count = 0;
    TextBoxx.forEach(function (textBox) {
        if (textBox.value.trim().length == 0) {
            if (count == 0) { textBox.focus(); }
            textBox.style.backgroundColor = "#FBE3E4"; count = 1; s = false;
        } else { textBox.style.backgroundColor = "#fff"; }
    });
    return s;
}
//////Ckeck TextBox Empty Status


//////Ckeck TextBox Empty Status
function EmptyCheckTextBoxAndDropdown(TextBoxx) {
    var s = true;
    var count = 0;
    TextBoxx.forEach(function (textBox) {
        if (textBox.value.trim().length == 0) {
            if (count == 0) { textBox.focus(); }
            textBox.style.backgroundColor = "#FBE3E4"; count = 1;
        }
        else {
            //var res = textBox.value;
            //if (res == '0') { textBox.style.backgroundColor = "#FBE3E4"; count = 1; }
            //else {//bbbbb
            //    if (res.substring(0, 6).toUpperCase() == 'SELECT') { textBox.style.backgroundColor = "#FBE3E4"; count = 1; }
            //    else { textBox.style.backgroundColor = "#fff";                
            //    }
            //}//bbbbb
            textBox.style.backgroundColor = "#fff";
            var type = textBox.type;
            if (type != 'text')//validation for dropdown
            {
                var res = textBox.value;
                if (res == '0')
                { res = ''; }
                if (res == '') { textBox.style.backgroundColor = "#FBE3E4"; count = 1; }
                else {
                    if (res.substring(0, 6).toUpperCase() == 'SELECT') { textBox.style.backgroundColor = "#FBE3E4"; count = 1; }
                    else { textBox.style.backgroundColor = "#fff"; }
                }
            }
        }
    });
    if (count == 1)
    { s = false; }
    return s;
}
//////Ckeck TextBox Empty Status

//////Ckeck TextBox Empty Status
function EmptyCheckTextBoxWithMessage(text, msg) {
    if (text.value.trim().length > 0) {
        text.focus();
        text.style.backgroundColor = "#FBE3E4";
        alert(msg);
        return false;
    }


}
//////Ckeck TextBox Empty Status




//////Ckeck DropDownList Empty Status
function EmptyCheckDropDownList(DropDown) {
    var s = true;
    var count = 0;
    debugger;
    DropDown.forEach(function (ddl) {
        if (ddl.value.trim().length == 0)
        { ddl.style.backgroundColor = "#FBE3E4"; count = 1; }
        else {///////
            var res = ddl.value;
            if (res == '0') { ddl.style.backgroundColor = "#FBE3E4"; count = 1; }
            else {//bbbbb
                if (res.substring(0, 6).toUpperCase() == 'SELECT') { ddl.style.backgroundColor = "#FBE3E4"; count = 1; }
                else { ddl.style.backgroundColor = "#fff"; }
            }//bbbbb
        }///////

    });
    if (count == 1)
    { s = false; }
    return s;
}
///Ckeck DropDownList Empty Status


//////Ckeck TextBox Empty Status
function EmptyCheckTextBoxDropDown(TextBoxx, DropDown) {
    var s = true;
    var count = 0;

    TextBoxx.forEach(function (textBox) {
        if (textBox.value.trim().length == 0) {
            textBox.focus();
            textBox.style.backgroundColor = "#FBE3E4"; count = 1;

        } else { textBox.style.backgroundColor = "#fff"; }
    });
    DropDown.forEach(function (ddl) {
        if (ddl.value.trim().length == 0)
        { ddl.style.backgroundColor = "#FBE3E4"; count = 1; }
        else {///////
            var res = ddl.value;
            if (res == '0') { ddl.style.backgroundColor = "#FBE3E4"; count = 1; }
            else {//bbbbb
                if (res.substring(0, 6).toUpperCase() == 'SELECT') { ddl.style.backgroundColor = "#FBE3E4"; count = 1; }
                else { ddl.style.backgroundColor = "#fff"; }
            }//bbbbb
        }///////

    });


    if (count == 1)
    { s = false; }

    return s;
}
//////Ckeck TextBox Empty Status



///Clear List Of text Box
function textBoxClear(TextBoxx) {
    var s = true;
    var count = 0;
    TextBoxx.forEach(function (textBox) {
        textBox.value = '';
    });
    return s;
}
///Clear List Of text Box






///Clear List Of DropDownList
function ddlClear(DropDown) {

    DropDown.forEach(function (ddl) {
        if (ddl.value.trim().length == 0)
        { ddl.value = '0'; }
        else {////
            var res = ddl.value;
            if (res != '0') { ddl.value = '0'; }
            else {
                if (res.substring(0, 6).toUpperCase() == 'SELECT') { ddl.value = '0'; }
            }
        }//////
    });
}
///Clear List Of DropDownList

/// <asp:TextBox ID="txtTeamSizeCount" runat="server" onkeypress="return validateFloatKeyPress(this,event);" ></asp:TextBox>
function validateFloatKeyPress(el, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }

    if (charCode == 46 && el.value.indexOf(".") !== -1) {
        return false;
    }

    if (el.value.indexOf(".") !== -1) {
        var range = document.selection.createRange();

        if (range.text != "") {
        }
        else {
            var number = el.value.split('.');
            if (number.length == 2 && number[1].length > 1)
                return false;
        }
    }

    return true;
}

function paging( startpage, endpage, type,startid,endid)
{
    if (type=='F')
    {
   
        startpage=1;
        endpage=10;
    }
    if (type == 'P')
    {
        startpage = startpage - 10;
        endpage = startpage + 9;
    }
    if (type == 'N') {
        startpage = parseInt(startpage) + 10;
        endpage = parseInt(endpage) + 10;
    }
    if (type == 'L') {
        startpage = 0;
        endpage = 10;
        //startpage = startpage + 20;
        //endpage = endpage + 20;
    }

    document.getElementById(startid).value = startpage;
    document.getElementById(endid).value = endpage;

   
}


function paginglast(res,startid, endid) {
    for (var i = 0; i < res.length; i++) {
        if (i == 0) {
            document.getElementById(startid).value = res[i].ROW_COUNT;
        }
         if (i == res.length - 1)
        { document.getElementById(endid).value = res[i].ROW_COUNT; }
        //tblfinal.innerHTML = tblfinal.innerHTML + "<tr><td style='text-align:center'>" + res[i].ROW_COUNT + "</td><td style='text-align:center'>" + res[i].USER_ID + "</td><td style='text-align:center'>" + res[i].EMP_NAME + "</td><td style='text-align:center'>" + res[i].EMP_CODE + "</td><td style='text-align:center'>" + res[i].USER_TYPE + "</td><td style='text-align:center'>" + res[i].MOBILE_NO + "</td><td style='text-align:center'>" + res[i].MOBILE_NO + "</td><td style='text-align:center'>" + res[i].EMAIL + "</td><td width='5%'> <a  id='" + res[i].ID + "' onclick='return_id(this.id);' style='cursor:pointer;'><img src='../../images/edit-icon.png'></a></td><td width='6%'><a id='" + res[i].ID + "' onclick='delete_id(this.id);' style='cursor:pointer;'><img src='../../images/delete-icon.png'></a></td></TR>";
        //start++;
    }
}